# ParkEase Kenya — Modern Parking System

A web-based parking management system developed for the DSA CAT. The system uses a C++17 backend, SQLite database, HTML/CSS/JavaScript frontend and a simple HTTP server.

## What it does

- Shows every parking slot and its current availability.
- Registers arriving vehicles and assigns an available slot.
- Stores vehicle and parking-session information in SQLite.
- Calculates parking duration automatically at exit.
- Applies the required Kenya parking charges:
  - Up to 30 minutes: KSh 0
  - More than 30 minutes up to 2 hours: KSh 50
  - More than 2 hours up to 4 hours: KSh 100
  - More than 4 hours up to 6 hours: KSh 300
  - More than 6 hours: KSh 500
- Records payment and releases the parking slot.
- Simulates the exit barrier opening after successful payment.
- Keeps recent parking records on the dashboard.

## Project structure

```text
modern-parking-system-task2/
├── backend/
│   ├── barrier.cpp
│   ├── barrier.h
│   ├── database.cpp
│   ├── database.h
│   ├── main.cpp
│   ├── parking.cpp
│   └── parking.h
├── database/
│   └── schema.sql
├── tests/
│   ├── parking_logic_test.cpp
│   └── smoke_test.sh
├── .github/workflows/build.yml
├── CMakeLists.txt
└── README.md
```

The web interface (HTML, CSS and JavaScript) is served directly by the C++ server, so there is no separate frontend build step.

## Requirements

- C++17 compiler
- CMake 3.16 or newer
- SQLite3 development library
- Linux/macOS environment with POSIX sockets (the supplied server uses POSIX networking)

## Build and run

```bash
mkdir build
cd build
cmake ..
cmake --build .
./parking_server
```

Open `http://localhost:8080` in a browser. If port 8080 is already occupied, run the server with another port, for example `PARKEASE_PORT=18080 ./parking_server`.

## Automatic verification

The repository includes a GitHub Actions workflow that builds the C++ project, runs the logic tests and runs the end-to-end smoke test automatically whenever the repository is updated.

## Run the built-in logic tests

From the `build` directory:

```bash
./parking_logic_test
```

The test checks the fee boundaries and registration validation used by the parking system.
