#include "factorial.h"
#include <iostream>
#include <limits>

int main() {
    std::cout << "Factorial Using Forward and Backward Stacks\n";
    std::cout << "Enter a non-negative integer: ";

    int n;
    while (!(std::cin >> n) || n < 0) {
        std::cout << "Invalid input. Enter a non-negative integer: ";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    Stack stack;
    std::vector<FactorialStep> forward;
    std::string error;

    if (!calculateForward(n, stack, forward, error)) {
        std::cout << error << '\n';
        return 1;
    }

    std::cout << "\nForward factorial calculation\n";
    for (const auto& step : forward) {
        std::cout << step.n << "! = " << step.value << '\n';
    }

    std::cout << "\nBackward stack calculation\n";
    auto backward = calculateBackward(stack, n);
    for (const auto& step : backward) {
        std::cout << step.n << "! = " << step.value << '\n';
    }

    return 0;
}
